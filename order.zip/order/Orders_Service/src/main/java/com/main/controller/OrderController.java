package com.main.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.main.model.Order;
import com.main.service.OrderServiceIntf;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	OrderServiceIntf orderser;

	@PostMapping("/saveO")

	public ResponseEntity<String> saveRegister(@RequestBody Order reg) {
		orderser.saveOrderDetails(reg);
		return new ResponseEntity<String>(" Added Successfully", HttpStatus.CREATED);
	}

	@GetMapping("/OList")
	public ResponseEntity<List<Order>> fetchData() {
		List<Order> list1 = orderser.fetchData();
		if (list1.size() == 0) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(list1, HttpStatus.OK);
	}

	@GetMapping("/getDetails/{orderId}")
	public ResponseEntity<Optional<Order>> getUserByPath(@PathVariable("orderId") int orderId) {
		System.out.println(orderId);
		Optional<Order> option = orderser.viewOrderDetails(orderId);
		if (option.isPresent())
			return new ResponseEntity<>(option, HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);

	}
	@GetMapping("/buyUsingOrderId/{orderId}")
    public ResponseEntity<Order> buyUsingId(@PathVariable("orderId") int orderId) {
        Order order = orderser.buyUsingOrderId(orderId).get();
        if (order!=null)
            return new ResponseEntity<>(order, HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}

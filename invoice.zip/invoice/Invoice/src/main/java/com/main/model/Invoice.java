package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Invoice_Tab")
public class Invoice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int in_id;
	private int ord_id;
	private float totalAmt;
	private String payStatus;
	public int getIn_id() {
		return in_id;
	}
	public void setIn_id(int in_id) {
		this.in_id = in_id;
	}
	public int getOrd_id() {
		return ord_id;
	}
	public void setOrd_id(int ord_id) {
		this.ord_id = ord_id;
	}
	public float getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(float totalAmt) {
		this.totalAmt = totalAmt;
	}
	public String getPayStatus() {
		return payStatus;
	}
	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}
	public Invoice(int ord_id, float totalAmt, String payStatus) {
		super();
		this.ord_id = ord_id;
		this.totalAmt = totalAmt;
		this.payStatus = payStatus;
	}
	
	public String toString() {
		return "Invoice [in_id=" + in_id + ", ord_id=" + ord_id + ", totalAmt=" + totalAmt + ", payStatus=" + payStatus
				+ "]";
	}
	public Invoice() {
}
}
	